﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Core.Migrations
{
    public partial class addStudentPersonalPhoto : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "IsERegistrationComplete",
                table: "Students",
                type: "bit(1)",
                nullable: false,
                defaultValue: "0");

            migrationBuilder.AddColumn<string>(
                name: "PersonalPhoto",
                table: "Students",
                type: "varchar(500)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsERegistrationComplete",
                table: "Students");

            migrationBuilder.DropColumn(
                name: "PersonalPhoto",
                table: "Students");
        }
    }
}
